<?php
$lang["setup_username"] = "Username";
$lang["setup_setup"] = "Setup";
$lang["setup_password"] = "Password";
$lang["setup_admin_account"] = "Admin account";
?>