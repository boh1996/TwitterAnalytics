<?php
$config["password_length"] = 8;
$config["hashing_iterations"] = 1;
$config["app_hashing_salt"] = "8jyXA6C2qU2qUQYGvrMxVGYA5aiczKxW";
$config["login_secret"] = "5RragPV4eAVcKDxVZVRhW4dZDOpW4XDP";
$config["include_numbers"] = false;
$config["standard_access_control_mode"] = "login"; // "nologin" or "login"
?>