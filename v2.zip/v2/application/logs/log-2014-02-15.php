<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 15-02-2014 14:07:51 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 14:08:11 --> Could not find the language line "One"
ERROR - 15-02-2014 14:08:11 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 1
ERROR - 15-02-2014 14:08:11 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 5
ERROR - 15-02-2014 14:08:11 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 7
ERROR - 15-02-2014 14:08:11 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:08:11 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 1
ERROR - 15-02-2014 14:08:11 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 5
ERROR - 15-02-2014 14:08:11 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 7
ERROR - 15-02-2014 14:08:11 --> Could not find the language line "One"
ERROR - 15-02-2014 14:08:11 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:08:11 --> Could not find the language line "One"
ERROR - 15-02-2014 14:08:11 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:08:11 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 14:08:25 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 14:08:26 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 14:08:38 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 14:11:02 --> Could not find the language line "One"
ERROR - 15-02-2014 14:11:02 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 1
ERROR - 15-02-2014 14:11:02 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 5
ERROR - 15-02-2014 14:11:02 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 7
ERROR - 15-02-2014 14:11:02 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:11:02 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 1
ERROR - 15-02-2014 14:11:02 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 5
ERROR - 15-02-2014 14:11:02 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 7
ERROR - 15-02-2014 14:11:02 --> Could not find the language line "One"
ERROR - 15-02-2014 14:11:02 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:11:02 --> Could not find the language line "One"
ERROR - 15-02-2014 14:11:02 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:11:03 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 14:12:44 --> Could not find the language line "One"
ERROR - 15-02-2014 14:12:44 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 1
ERROR - 15-02-2014 14:12:44 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 5
ERROR - 15-02-2014 14:12:44 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 7
ERROR - 15-02-2014 14:12:44 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:12:44 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 1
ERROR - 15-02-2014 14:12:44 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 5
ERROR - 15-02-2014 14:12:44 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 7
ERROR - 15-02-2014 14:12:44 --> Could not find the language line "One"
ERROR - 15-02-2014 14:12:44 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:12:44 --> Could not find the language line "One"
ERROR - 15-02-2014 14:12:44 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:13:19 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 14:13:34 --> 404 Page Not Found --> assets
