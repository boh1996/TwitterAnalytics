<?php
$config["api_bad_request_code"] = 400;
$config["api_error_while_saving_code"] = 409;
$config["api_not_found_code"] = 404;
$config["api_created_code"] = 201;
$config["api_forbidden_error"] = 403;
$config["api_accepted_code"] = 202;
?>