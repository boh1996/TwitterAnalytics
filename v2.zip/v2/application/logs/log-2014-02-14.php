<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 14-02-2014 15:06:16 --> 404 Page Not Found --> assets
ERROR - 14-02-2014 15:08:57 --> 404 Page Not Found --> assets
ERROR - 14-02-2014 15:08:58 --> 404 Page Not Found --> assets
ERROR - 14-02-2014 15:11:06 --> 404 Page Not Found --> assets
ERROR - 14-02-2014 15:11:35 --> 404 Page Not Found --> assets
