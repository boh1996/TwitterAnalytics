<?php
$config["password_length"] = 8;
$config["hashing_iterations"] = 1;
$config["app_hashing_salt"] = "DHrPTKV18jxwsrhKxWfk67NITPkZqnIf";
$config["login_secret"] = "P8xAthCBWP2I2arba4hwA1fJlk8PCO9T";
$config["include_numbers"] = false;
$config["standard_access_control_mode"] = "login"; // "nologin" or "login"
?>