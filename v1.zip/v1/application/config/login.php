<?php
$config["password_length"] = 8;
$config["hashing_iterations"] = 1;
$config["app_hashing_salt"] = "7cDMo3v2jvELzXxH0YSJDZP6Ed3YpV0I";
$config["login_secret"] = "iXEQ8XGXltghqPUX7S9kra5VzJSaeIsh";
$config["include_numbers"] = false;
$config["standard_access_control_mode"] = "login"; // "nologin" or "login"
?>