<?php
$config["password_length"] = 8;
$config["hashing_iterations"] = 1;
$config["app_hashing_salt"] = "A7iZrWQpnzJRyM5M1K35z84WVTSBeZ83";
$config["login_secret"] = "2ALXhS1fIARtuVUA8DVy1VJHC5HZlAEm";
$config["include_numbers"] = false;
$config["standard_access_control_mode"] = "login"; // "nologin" or "login"
?>