<?php
$config["password_length"] = 8;
$config["hashing_iterations"] = 1;
$config["app_hashing_salt"] = "9eojy05bvDRLJz05OKlQxYOHwFkyqW4L";
$config["login_secret"] = "cw2jdty0AMRLexIeVrSI72oACkoMzvRS";
$config["include_numbers"] = false;
$config["standard_access_control_mode"] = "login"; // "nologin" or "login"
?>