<?php
$config["password_length"] = 8;
$config["hashing_iterations"] = 1;
$config["app_hashing_salt"] = "%APP_HASHING_SALT%";
$config["login_secret"] = "%LOGIN_SECRET%";
$config["include_numbers"] = false;
$config["standard_access_control_mode"] = "login"; // "nologin" or "login"
?>