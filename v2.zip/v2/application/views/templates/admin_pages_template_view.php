<?= $this->user_control->LoadTemplate("pages_list_view"); ?>

<?= $this->user_control->LoadTemplate("new_page_view"); ?>