<?php
/*$config["useragent"] = "CodeIgniter";
$config["protocol"] = "mail";
$config["mailpath"] = "/usr/sbin/sendmail";
$config["smtp_host"] = NULL;
$config["smtp_user"] = NULL;
$config["smtp_pass"] = NULL;
$config["smtp_port"] = NULL;
$config["smtp_timeout"] = NULL;
$config["wordwrap"] = True;
$config["wrapchars"] = 76;
$config["mailtype"] = "html"; // html or text
$config["charset"] = "";
$config["charset"] = "utf-8";
$config["validate"] = false; // Whether or not to do email validation
$config["priority"] = 5; // Email priority, 1 -5
$config["crlf"] = "\n";
$config["newline"] = "\n";
$config["bcc_batch_mode"] = False;
$config["bcc_batch_size"] = 200;*/
?>