<?php
$lang["sort_per_year"] = "year";
$lang["sort_per_month"] = "month";
$lang["sort_per_week"] = "week";
$lang["sort_per_day"] = "day";
$lang["sort_per_half_day"] = "12 hours";
$lang["sort_per_quater_of_day"] = "6 hours";
$lang["sort_per_tree_hours"] = "3 hours";
$lang["sort_per_hour"] = "hour";
$lang["sort_per_half_hour"] = "30 minutes";
$lang["sort_per_fifteen_minutes"] = "15 minutes";
$lang["sort_per_five_minutes"] = "5 minutes";
$lang["sort_per_minute"] = "minute";
?>