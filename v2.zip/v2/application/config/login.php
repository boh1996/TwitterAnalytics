<?php
$config["password_length"] = 8;
$config["hashing_iterations"] = 1;
$config["app_hashing_salt"] = "hsRtmndV0p4Y49Jk2RfuZpFRHia9dDD5YEunlqdDumhP0ttGxWm753iSLSuL3SpB";
$config["login_secret"] = "VD5TR7ZKqHtqAOW9iotGPtnxKksl3vleIAM3chsaWa3wVRU5uXmFY1tRyj3iKjOM";
$config["include_numbers"] = false;
$config["standard_access_control_mode"] = "login"; // "nologin" or "login"
?>