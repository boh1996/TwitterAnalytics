<div class="form-group url-object" style="min-width:600px;">
	<label class="col-sm-2 control-label"><?= $this->lang->line("admin_add_url"); ?></label>
	<div class="col-sm-10">
		<div class="input-group">
			<input  type="text" class="form-control create-url add-url" placeholder="<?= $this->lang->line("admin_add_url"); ?>" >
			<span class="input-group-btn">
				<button class="btn btn-lg btn-danger button-addon remove-url" type="button"><?= $this->lang->line("admin_remove_item"); ?></button>
			</span>
		</div>
	</div>
</div>