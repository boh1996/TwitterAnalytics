<?php
$lang["user_alerts"] = "Alerts";
$lang["user_word"] = "Word";
$lang["user_count"] = "Count";
$lang["user_no_words_found"] = "No words found";
$lang["user_rows"] = "Rows:";
$lang["user_unique_tweets"] = "Unique tweets";
$lang["user_type"] = "Type";
$lang["user_type_alert_string"] = "Alert string";
$lang["user_type_word"] = "Word";
$lang["user_refresh"] = "Refresh";
$lang["user_connected_words"] = "Connected words[Count]";
$lang["user_no_connected_words"] = "No connected words";
$lang["user_words_from_tweets"] = "Data from {{number}} tweet(s)";
?>