<!-- Replaced strings -->
<form class="form-signin form-horizontal" id="replaced_strings_form" role="form">
	<div class="col-sm-10 col-sm-offset-4">
		<h2 class="form-signin-heading"><?= $this->lang->line("replaced_string_settings"); ?></h2>
	</div>

	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-6">
			<input type="text" id="alert_word_count" name="alert_word_count" class="form-control" placeholder="<?= $this->lang->line("username"); ?>" required autofocus>
		</div>
	</div>
	</div>
</form>