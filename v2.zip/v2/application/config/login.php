<?php
$config["password_length"] = 8;
$config["hashing_iterations"] = 1;
$config["app_hashing_salt"] = "PWFdKIVQFhMGlTBdyoVTSZLbL8CzRI8p";
$config["login_secret"] = "hqiqVF4EfRjWvsZxe3RG7LZKENhTWD2X";
$config["include_numbers"] = false;
$config["standard_access_control_mode"] = "login"; // "nologin" or "login"
?>