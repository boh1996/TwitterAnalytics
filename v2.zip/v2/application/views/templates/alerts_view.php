<div class="alert alert-danger alert-dismissable" id="alertsErrorTemplate">
	<button type="button" class="close" data-dismiss="alert">&times;</button>
	{{message}}
</div>

<div class="alert alert-success alert-dismissable" id="alertsSuccessTemplate">
	<button type="button" class="close" data-dismiss="alert">&times;</button>
 	{{message}}
</div>

<div class="alert alert-info alert-dismissable" id="alertsInfoTemplate">
	<button type="button" class="close" data-dismiss="alert">&times;</button>
	{{message}}
</div>

<div class="alert alert-warning alert-dismissable" id="alertsWarningTemplate">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  {{message}}
</div>