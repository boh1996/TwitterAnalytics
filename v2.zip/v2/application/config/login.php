<?php
$config["password_length"] = 8;
$config["hashing_iterations"] = 1;
$config["app_hashing_salt"] = "dKuOwyuw85vgNTxDQXSdT5NWGSDy1Vva";
$config["login_secret"] = "QaySjWKBdfTqNsM3eTSshJkwDjgJRaGb";
$config["include_numbers"] = false;
$config["standard_access_control_mode"] = "login"; // "nologin" or "login"
?>