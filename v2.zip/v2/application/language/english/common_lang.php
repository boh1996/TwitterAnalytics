<?php
$lang["app_name"] = "Twitter Statistics";
$lang["sign_in"] = "Sign in";
$lang["sign_out"] = "Sign out";
$lang["control_panel"] = "Control panel";
$lang["viewer_section"] = "Analytics viewer";
$lang["toggle_navigation"] = "Toggle navigation";
$lang["followers"] = "Followers";
$lang["topics"] = "Topics";
$lang["alerts"] = "Alerts";
$lang["please_sign_in"] = "Please sign in!";
$lang["sign_in_button"] = "Sign in!";
$lang["username"] = "Username";
$lang["sign_in_page"] = "Sign In";
$lang["password"] = "Password";
$lang["admin_page"] = "Admin page!";
$lang["error_inserting_tweet"] = "Can't insert tweet {{tweet_id}} into database!";
$lang["category_first"] = "First";
$lang["categort_second"] = "Second";
?>