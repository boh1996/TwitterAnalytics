<?php
$config["password_length"] = 8;
$config["hashing_iterations"] = 1;
$config["app_hashing_salt"] = "SVigQ1z5JUVmc3SgIFb7oD8t9WkNkHhQ";
$config["login_secret"] = "b6hNB1x4ReCoq9eWN12TVOWYCs7uYKwc";
$config["include_numbers"] = false;
$config["standard_access_control_mode"] = "login"; // "nologin" or "login"
?>