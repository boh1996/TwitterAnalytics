<?php
$config["categories"] = array(
	"1" => array(
		"key" => "1",
 		"language_key" => "category_first",
		"color" => "#0066FF"
	),
	"2" => array(
		"key" => "2",
 		"language_key" => "categort_second",
		"color" => "#CC0000"
	)
)
?>