<?php
$lang["sign_in_empty_password_field"] = "Please fill out the password field!";
$lang["sign_in_empty_username_field"] = "Please fill out the username field!";
$lang["sign_in_empty_fields"] = "Please enter your username and password!";
$lang["sign_in_missing_username"] = "Missing username!";
$lang["sign_in_missing_password"] = "Missing password!";
$lang["sign_in_missing_username_and_password"] = "Missing username and password!";
$lang["sign_in_secuirty_details"] = "Incorrect post format!";
$lang["sign_in_username_not_found"] = "No user with that username exists!";
$lang["sign_in_error_occured"] = "An error occured, please try again!";
$lang["sign_in_password_not_correct"] = "The specified password is incorrect!";
$lang["sign_in_success_redirecting"] = "You have successfully been logged in, you will now be redirected!";
?>