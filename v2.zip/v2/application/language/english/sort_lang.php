<?php
$lang["sort_per_year"] = "Per year";
$lang["sort_per_month"] = "Per month";
$lang["sort_per_week"] = "Per week";
$lang["sort_per_day"] = "Per day";
$lang["sort_per_half_day"] = "Per 12 hours";
$lang["sort_per_quater_of_day"] = "Per 6 hours";
$lang["sort_per_tree_hours"] = "Per 3 hours";
$lang["sort_per_hour"] = "Per hour";
$lang["sort_per_half_hour"] = "Per 30 minutes";
$lang["sort_per_fifteen_minutes"] = "Per 15 minutes";
$lang["sort_per_five_minutes"] = "Per 5 minutes";
$lang["sort_per_minute"] = "Per minute";
?>