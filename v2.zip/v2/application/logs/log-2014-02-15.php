<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 15-02-2014 14:07:51 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 14:08:11 --> Could not find the language line "One"
ERROR - 15-02-2014 14:08:11 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 1
ERROR - 15-02-2014 14:08:11 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 5
ERROR - 15-02-2014 14:08:11 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 7
ERROR - 15-02-2014 14:08:11 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:08:11 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 1
ERROR - 15-02-2014 14:08:11 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 5
ERROR - 15-02-2014 14:08:11 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 7
ERROR - 15-02-2014 14:08:11 --> Could not find the language line "One"
ERROR - 15-02-2014 14:08:11 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:08:11 --> Could not find the language line "One"
ERROR - 15-02-2014 14:08:11 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:08:11 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 14:08:25 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 14:08:26 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 14:08:38 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 14:11:02 --> Could not find the language line "One"
ERROR - 15-02-2014 14:11:02 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 1
ERROR - 15-02-2014 14:11:02 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 5
ERROR - 15-02-2014 14:11:02 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 7
ERROR - 15-02-2014 14:11:02 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:11:02 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 1
ERROR - 15-02-2014 14:11:02 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 5
ERROR - 15-02-2014 14:11:02 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 7
ERROR - 15-02-2014 14:11:02 --> Could not find the language line "One"
ERROR - 15-02-2014 14:11:02 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:11:02 --> Could not find the language line "One"
ERROR - 15-02-2014 14:11:02 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:11:03 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 14:12:44 --> Could not find the language line "One"
ERROR - 15-02-2014 14:12:44 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 1
ERROR - 15-02-2014 14:12:44 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 5
ERROR - 15-02-2014 14:12:44 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 7
ERROR - 15-02-2014 14:12:44 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:12:44 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 1
ERROR - 15-02-2014 14:12:44 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 5
ERROR - 15-02-2014 14:12:44 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 7
ERROR - 15-02-2014 14:12:44 --> Could not find the language line "One"
ERROR - 15-02-2014 14:12:44 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:12:44 --> Could not find the language line "One"
ERROR - 15-02-2014 14:12:44 --> Could not find the language line "Two"
ERROR - 15-02-2014 14:13:19 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 14:13:34 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:03:00 --> Could not find the language line "One"
ERROR - 15-02-2014 15:03:00 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 1
ERROR - 15-02-2014 15:03:00 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 5
ERROR - 15-02-2014 15:03:00 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 7
ERROR - 15-02-2014 15:03:00 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:03:00 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 1
ERROR - 15-02-2014 15:03:00 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 5
ERROR - 15-02-2014 15:03:00 --> Severity: Notice  --> Undefined variable: cat_id R:\TwitterAnalytics\v2\application\views\templates\new_string_view.php 7
ERROR - 15-02-2014 15:03:00 --> Could not find the language line "One"
ERROR - 15-02-2014 15:03:00 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:03:00 --> Could not find the language line "One"
ERROR - 15-02-2014 15:03:00 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:03:09 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:06:56 --> Could not find the language line "One"
ERROR - 15-02-2014 15:06:56 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:06:56 --> Could not find the language line "One"
ERROR - 15-02-2014 15:06:56 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:06:56 --> Could not find the language line "One"
ERROR - 15-02-2014 15:06:56 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:01 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:01 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:01 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:01 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:01 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:01 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:02 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:07:12 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:12 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:12 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:12 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:12 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:12 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:13 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:07:28 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:28 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:28 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:28 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:28 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:28 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:29 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:07:39 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:39 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:39 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:39 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:39 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:39 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:41 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:41 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:41 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:41 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:41 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:41 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:41 --> Could not find the language line "One"
ERROR - 15-02-2014 15:07:41 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:07:42 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:09:28 --> Could not find the language line "One"
ERROR - 15-02-2014 15:09:28 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:09:28 --> Could not find the language line "One"
ERROR - 15-02-2014 15:09:28 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:09:28 --> Could not find the language line "One"
ERROR - 15-02-2014 15:09:28 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:09:28 --> Could not find the language line "One"
ERROR - 15-02-2014 15:09:28 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:09:29 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:09:53 --> Could not find the language line "One"
ERROR - 15-02-2014 15:09:53 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:09:53 --> Could not find the language line "One"
ERROR - 15-02-2014 15:09:53 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:09:53 --> Could not find the language line "One"
ERROR - 15-02-2014 15:09:53 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:09:53 --> Could not find the language line "One"
ERROR - 15-02-2014 15:09:53 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:09:54 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:12:15 --> Could not find the language line "One"
ERROR - 15-02-2014 15:12:15 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:12:15 --> Could not find the language line "One"
ERROR - 15-02-2014 15:12:15 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:12:15 --> Could not find the language line "One"
ERROR - 15-02-2014 15:12:15 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:12:15 --> Could not find the language line "One"
ERROR - 15-02-2014 15:12:15 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:12:16 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:16:00 --> Could not find the language line "One"
ERROR - 15-02-2014 15:16:00 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:16:00 --> Could not find the language line "One"
ERROR - 15-02-2014 15:16:00 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:16:00 --> Could not find the language line "One"
ERROR - 15-02-2014 15:16:00 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:16:00 --> Could not find the language line "One"
ERROR - 15-02-2014 15:16:00 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:16:01 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:17:46 --> Could not find the language line "One"
ERROR - 15-02-2014 15:17:46 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:17:46 --> Could not find the language line "One"
ERROR - 15-02-2014 15:17:46 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:17:46 --> Could not find the language line "One"
ERROR - 15-02-2014 15:17:46 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:17:46 --> Could not find the language line "One"
ERROR - 15-02-2014 15:17:46 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:17:47 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:19:13 --> Severity: Warning  --> Invalid argument supplied for foreach() R:\TwitterAnalytics\v2\application\models\page_model.php 71
ERROR - 15-02-2014 15:19:13 --> Severity: Warning  --> Invalid argument supplied for foreach() R:\TwitterAnalytics\v2\application\models\page_model.php 98
ERROR - 15-02-2014 15:19:56 --> Severity: Notice  --> Undefined index: strings R:\TwitterAnalytics\v2\application\models\page_model.php 147
ERROR - 15-02-2014 15:19:56 --> Severity: Warning  --> Invalid argument supplied for foreach() R:\TwitterAnalytics\v2\application\models\page_model.php 71
ERROR - 15-02-2014 15:19:56 --> Severity: Notice  --> Undefined index: urls R:\TwitterAnalytics\v2\application\models\page_model.php 148
ERROR - 15-02-2014 15:19:56 --> Severity: Warning  --> Invalid argument supplied for foreach() R:\TwitterAnalytics\v2\application\models\page_model.php 98
ERROR - 15-02-2014 15:22:47 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:47 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:47 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:47 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:47 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:47 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:47 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:47 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:47 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:47 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:47 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:47 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:47 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:47 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:48 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:22:57 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:57 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:57 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:57 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:57 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:57 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:57 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:57 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:57 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:57 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:57 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:57 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:57 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:57 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "One"
ERROR - 15-02-2014 15:22:59 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:23:00 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "One"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "One"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "One"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "One"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "One"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "One"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "One"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "One"
ERROR - 15-02-2014 15:23:39 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:23:40 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:24:30 --> Could not find the language line "One"
ERROR - 15-02-2014 15:24:30 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:24:30 --> Could not find the language line "One"
ERROR - 15-02-2014 15:24:30 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:24:30 --> Could not find the language line "One"
ERROR - 15-02-2014 15:24:30 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:24:31 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:24:34 --> Could not find the language line "One"
ERROR - 15-02-2014 15:24:34 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:24:34 --> Could not find the language line "One"
ERROR - 15-02-2014 15:24:34 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:24:34 --> Could not find the language line "One"
ERROR - 15-02-2014 15:24:34 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:24:35 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:24:43 --> Could not find the language line "One"
ERROR - 15-02-2014 15:24:43 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:24:43 --> Could not find the language line "One"
ERROR - 15-02-2014 15:24:43 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:24:43 --> Could not find the language line "One"
ERROR - 15-02-2014 15:24:43 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:24:44 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:25:34 --> Could not find the language line "One"
ERROR - 15-02-2014 15:25:34 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:25:34 --> Could not find the language line "One"
ERROR - 15-02-2014 15:25:34 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:25:34 --> Could not find the language line "One"
ERROR - 15-02-2014 15:25:34 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:25:35 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:25:48 --> Could not find the language line "One"
ERROR - 15-02-2014 15:25:48 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:25:48 --> Could not find the language line "One"
ERROR - 15-02-2014 15:25:48 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:25:48 --> Could not find the language line "One"
ERROR - 15-02-2014 15:25:48 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:25:49 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 15:26:18 --> Could not find the language line "One"
ERROR - 15-02-2014 15:26:18 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:26:18 --> Could not find the language line "One"
ERROR - 15-02-2014 15:26:18 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:26:20 --> Could not find the language line "One"
ERROR - 15-02-2014 15:26:20 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:26:20 --> Could not find the language line "One"
ERROR - 15-02-2014 15:26:20 --> Could not find the language line "Two"
ERROR - 15-02-2014 15:26:20 --> Could not find the language line "One"
ERROR - 15-02-2014 15:26:20 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:53:15 --> Could not find the language line "One"
ERROR - 15-02-2014 17:53:15 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:53:15 --> Could not find the language line "One"
ERROR - 15-02-2014 17:53:15 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:53:15 --> Could not find the language line "One"
ERROR - 15-02-2014 17:53:15 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:53:29 --> Could not find the language line "One"
ERROR - 15-02-2014 17:53:29 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:53:29 --> Could not find the language line "One"
ERROR - 15-02-2014 17:53:29 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:53:31 --> Could not find the language line "One"
ERROR - 15-02-2014 17:53:31 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:53:31 --> Could not find the language line "One"
ERROR - 15-02-2014 17:53:31 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:53:31 --> Could not find the language line "One"
ERROR - 15-02-2014 17:53:31 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:53:37 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 17:54:00 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 17:54:14 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:54:20 --> Severity: Notice  --> Undefined variable: error_type R:\TwitterAnalytics\v2\application\controllers\api\api_scraper.php 138
ERROR - 15-02-2014 17:56:42 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 17:56:45 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 17:56:47 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 17:58:23 --> Could not find the language line "One"
ERROR - 15-02-2014 17:58:23 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:58:23 --> Could not find the language line "One"
ERROR - 15-02-2014 17:58:23 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:58:23 --> Could not find the language line "One"
ERROR - 15-02-2014 17:58:23 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:58:24 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 17:58:32 --> Could not find the language line "One"
ERROR - 15-02-2014 17:58:32 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:58:32 --> Could not find the language line "One"
ERROR - 15-02-2014 17:58:32 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:58:34 --> Could not find the language line "One"
ERROR - 15-02-2014 17:58:34 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:58:34 --> Could not find the language line "One"
ERROR - 15-02-2014 17:58:34 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:58:34 --> Could not find the language line "One"
ERROR - 15-02-2014 17:58:34 --> Could not find the language line "Two"
ERROR - 15-02-2014 17:58:35 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 17:58:36 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 17:59:29 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 17:59:31 --> 404 Page Not Found --> assets
ERROR - 15-02-2014 18:03:55 --> 404 Page Not Found --> assets
